<?php
/*
Plugin Name: Custom Popup with Gravity Form
Description: A simple plugin to add a popup triggered by a class with a Gravity Form inside.
Version: 1.0
Author: Advantage Media | Forbes Books
*/


function custom_popup_form_enqueue_styles() {
  wp_enqueue_style('custom-popup-style', plugin_dir_url(__FILE__) . 'css/stylesheet.css');
}
add_action('wp_enqueue_scripts', 'custom_popup_form_enqueue_styles');



// Add settings menu item
function custom_popup_add_settings_menu() {
  add_options_page(
      'Custom Popup Settings',
      'Custom Popup Settings',
      'manage_options',
      'custom-popup-settings',
      'custom_popup_settings_page'
  );
}
add_action('admin_menu', 'custom_popup_add_settings_menu');

// Display settings page
function custom_popup_settings_page() {
  ?>
  <div class="wrap">
      <h1>Custom Popup Settings.</h1>
        <p>Add your Gravity Form ID Number</p>
      <form method="post" action="options.php">
          <?php
          settings_fields('custom_popup_settings_group');
          do_settings_sections('custom-popup-settings');
          submit_button();
          ?>
      </form>
  </div>
  <?php
}

// Register settings
function custom_popup_register_settings() {
  register_setting('custom_popup_settings_group', 'custom_popup_gravity_form_id');
  
  add_settings_section(
      'custom_popup_settings_section',
      'Popup Settings',
      null,
      'custom-popup-settings'
  );

  add_settings_field(
      'custom_popup_gravity_form_id',
      'Gravity Form ID',
      'custom_popup_gravity_form_id_field',
      'custom-popup-settings',
      'custom_popup_settings_section'
  );
}
add_action('admin_init', 'custom_popup_register_settings');

// Input field for Gravity Form ID
function custom_popup_gravity_form_id_field() {
  $gravity_form_id = get_option('custom_popup_gravity_form_id', 1); // Default to 1 if not set
  echo '<input type="text" name="custom_popup_gravity_form_id" value="' . esc_attr($gravity_form_id) . '" />';
}

function custom_popup_form_shortcode() {
  // Get the user-defined Gravity Form ID from settings
  $gravity_form_id = get_option('custom_popup_gravity_form_id', 1); // Default to form ID 1 if not set
  ob_start();
  ?>
  <!-- Trigger button with a common CSS class -->
  <button class="trigger-popup et_pb_button">Subscribe</button>

  <!-- Popup container -->
  <div id="popupForm" style="display:none; position:fixed; top:50%; left:50%; transform:translate(-50%, -50%); background:white; padding:20px; z-index:9999; border-radius:8px;">
    <span id="popupClose" style="cursor:pointer; position:absolute; top:10px; right:10px; font-size:20px;">&times;</span>
    <!-- Gravity Form Shortcode -->
    <?php echo do_shortcode('[gravityform id="' . esc_attr($gravity_form_id) . '" title="false" description="false"]'); ?>
  </div>

  <!-- Background overlay -->
  <div id="popupOverlay" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0, 0, 0, 0.5); z-index:9998;"></div>

  <?php
  return ob_get_clean();
}
add_shortcode('custom_popup_form', 'custom_popup_form_shortcode');


// Enqueue the JS and CSS separately for modularity
function custom_popup_form_enqueue_scripts() {
  ?>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      var triggerElements = document.querySelectorAll('.trigger-popup');

      if (triggerElements.length) {
        // Add click event listeners to each trigger element
        triggerElements.forEach(function(trigger) {
          trigger.addEventListener('click', function() {
            document.getElementById('popupForm').style.display = 'block';
            document.getElementById('popupOverlay').style.display = 'block';
          });
        });

        // Close popup when clicking the close button or overlay
        document.getElementById('popupClose').addEventListener('click', function() {
          document.getElementById('popupForm').style.display = 'none';
          document.getElementById('popupOverlay').style.display = 'none';
        });

        document.getElementById('popupOverlay').addEventListener('click', function() {
          document.getElementById('popupForm').style.display = 'none';
          document.getElementById('popupOverlay').style.display = 'none';
        });
      }
    });
  </script>
  <?php
}
add_action('wp_footer', 'custom_popup_form_enqueue_scripts');
